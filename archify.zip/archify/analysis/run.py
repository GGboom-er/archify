"""Isolated interpreter entry; only the installed analyzer is added to sys.path."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from analysis.__main__ import main

if __name__ == '__main__':
    sys.exit(main())
